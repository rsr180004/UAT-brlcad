#include "common.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stddef.h>

#include "vmath.h"		/* vector math macros */
#include "bu/app.h"
#include "bu/list.h"
#include "bu/time.h"
#include "bu/parse.h"
#include "bu/vls.h"
#include "bu/log.h"
#include "raytrace.h"		/* librt interface definitions */

#include "./rtuif.h"
#include "../../include/analyze/worker.h"
#include "analyze.h"
#include "../libanalyze/analyze_private.h"



const char * progname;

void
usage(const char *s)
{
    if (s) (void)fputs(s, stderr);
    bu_exit(1, "Usage: %s geom.g obj [obj...] < rayfile \n", progname);
}


char* pointToString(const point_t point, char* buffer, size_t bufferSize) {
    // Check for null pointer or insufficient buffer size
    if (point == NULL || buffer == NULL || bufferSize < 16) {
        return NULL;
    }

    // Initialize the string to an empty string
    buffer[0] = '\0';

    // Add opening parenthesis
    strcat(buffer, "(");

    // Convert and concatenate each double to the string
    char temp[16];
    for (int i = 0; i < ELEMENTS_PER_POINT; i++) {
        snprintf(temp, sizeof(temp), "%.6f", point[i]);
        strcat(buffer, temp);

        // Add a comma and space after each element except the last one
        if (i < ELEMENTS_PER_POINT - 1) {
            strcat(buffer, ", ");
        }
    }

    // Add closing parenthesis
    strcat(buffer, ")");
    return buffer;
}

/**
 * rt_shootray() was told to call this on a hit.
 *
 * This callback routine utilizes the application structure which
 * describes the current state of the raytrace.
 *
 * This callback routine is provided a circular linked list of
 * partitions, each one describing one in and out segment of one
 * region for each region encountered.
 *
 * The 'segs' segment list is unused in this example.
 */
int
hit(struct application *ap, struct partition *PartHeadp, struct seg *UNUSED(segs))
{
    /* iterating over partitions, this will keep track of the current
     * partition we're working on.
     */
    struct partition *pp;

    /* will serve as a pointer for the entry and exit hitpoints */
    struct hit *hitp;

    /* will serve as a pointer to the solid primitive we hit */
    struct soltab *stp;

    /* will contain surface curvature information at the entry */
    struct curvature cur = RT_CURVATURE_INIT_ZERO;

    /* will contain our hit point coordinate */
    point_t pt;

    /* will contain normal vector where ray enters geometry */
     vect_t inormal;

    /* will contain normal vector where ray exits geometry */
    vect_t onormal;

    /* iterate over each partition until we get back to the head.
     * each partition corresponds to a specific homogeneous region of
     * material.
     */
    for (pp=PartHeadp->pt_forw; pp != PartHeadp; pp = pp->pt_forw) {

    /* print the name of the region we hit as well as the name of
     * the primitives encountered on entry and exit.
     */
    bu_log("\n--- Hit region %s (in %s, out %s)\n",
           pp->pt_regionp->reg_name,
           pp->pt_inseg->seg_stp->st_name,
           pp->pt_outseg->seg_stp->st_name );

    /* entry hit point, so we type less */
    hitp = pp->pt_inhit;

    /* construct the actual (entry) hit-point from the ray and the
     * distance to the intersection point (i.e., the 't' value).
     */
    VJOIN1(pt, ap->a_ray.r_pt, hitp->hit_dist, ap->a_ray.r_dir);

    /* primitive we encountered on entry */
    stp = pp->pt_inseg->seg_stp;

    /* compute the normal vector at the entry point, flipping the
     * normal if necessary.
     */
    RT_HIT_NORMAL(inormal, hitp, stp, &(ap->a_ray), pp->pt_inflip);

    /* print the entry hit point info */
    rt_pr_hit("  In", hitp);
    VPRINT(   "  Ipoint", pt);
    VPRINT(   "  Inormal", inormal);

    char origin_str[64];
    pointToString(ap->a_ray.r_pt, origin_str, sizeof(origin_str));
    char ray_dir_str[64];
    pointToString(ap->a_ray.r_dir, ray_dir_str, sizeof(ray_dir_str));
    char pt_str[64];
    pointToString(pt, pt_str, sizeof(pt_str));
    char normal_str[64];
    pointToString(inormal, normal_str, sizeof(normal_str));

    // Print to file
    const char* filename = "ray_info.txt";

    // Open the file in append mode (creates if it doesn't exist)
    FILE* file = fopen(filename, "a");

    if (file == NULL) {
        // Handle error if unable to open the file
        perror("Error opening file");
        exit(0); // may cause errors?
    }

    // Write ray origin
    fprintf(file, "%s*", origin_str);
    // Write ray direction
    fprintf(file, "%s*", ray_dir_str);
    // Write hitpoint
    fprintf(file, "%s*", pt_str);
    // Write normal
    fprintf(file, "%s\n", normal_str);

    // Close the file when done
    fclose(file);

    /* This next macro fills in the curvature information which
     * consists on a principle direction vector, and the inverse
     * radii of curvature along that direction and perpendicular
     * to it.  Positive curvature bends toward the outward
     * pointing normal.
     */
    RT_CURVATURE(&cur, hitp, pp->pt_inflip, stp);

    /* print the entry curvature information */
    VPRINT("PDir", cur.crv_pdir);
    bu_log(" c1=%g\n", cur.crv_c1);
    bu_log(" c2=%g\n", cur.crv_c2);

    /* exit point, so we type less */
    hitp = pp->pt_outhit;

    /* construct the actual (exit) hit-point from the ray and the
     * distance to the intersection point (i.e., the 't' value).
     */
    VJOIN1(pt, ap->a_ray.r_pt, hitp->hit_dist, ap->a_ray.r_dir);

    /* primitive we exited from */
    stp = pp->pt_outseg->seg_stp;

    /* compute the normal vector at the exit point, flipping the
     * normal if necessary.
     */
    RT_HIT_NORMAL(onormal, hitp, stp, &(ap->a_ray), pp->pt_outflip);

    /* print the exit hit point info */
    rt_pr_hit("  Out", hitp);
    VPRINT(   "  Opoint", pt);
    VPRINT(   "  Onormal", onormal);
    }

    /* A more complicated application would probably fill in a new
     * local application structure and describe, for example, a
     * reflected or refracted ray, and then call rt_shootray() for
     * those rays.
     */

    /* Hit routine callbacks generally return 1 on hit or 0 on miss.
     * This value is returned by rt_shootray().
     */
    return 1;
}


/**
 * This is a callback routine that is invoked for every ray that
 * entirely misses hitting any geometry.  This function is invoked by
 * rt_shootray() if the ray encounters nothing.
 */
int
miss(struct application *ap)
{
    //bu_log("missed\n");

    // Print to file
    const char* filename = "ray_info.txt";

    // Open the file in append mode (creates if it doesn't exist)
    FILE* file = fopen(filename, "a");

    if (file == NULL) {
        // Handle error if unable to open the file
        perror("Error opening file");
        exit(0); // may cause errors?
    }

    char origin_str[64];
    pointToString(ap->a_ray.r_pt, origin_str, sizeof(origin_str));
    char ray_dir_str[64];
    pointToString(ap->a_ray.r_dir, ray_dir_str, sizeof(ray_dir_str));

    // Write ray origin
    fprintf(file, "%s*", origin_str);
    // Write ray direction
    fprintf(file, "%s*", ray_dir_str);


    // Write hitpoint
    fprintf(file, "%s*", "miss");
    // Write normal
    fprintf(file, "%s\n", "miss");

    // Close the file when done
    fclose(file);
    return 0;
}

static int
op_overlap(struct application *ap, struct partition *UNUSED(pp),
		struct region *UNUSED(reg1), struct region *UNUSED(reg2),
		struct partition *UNUSED(hp))
{
    RT_CK_APPLICATION(ap);
    return 0;
}

void
get_random_rays(fastf_t *rays, long int craynum, point_t center, fastf_t radius)
{
    long int i = 0;
    point_t p1, p2;
    if (!rays) return;
    for (i = 0; i < craynum; i++) {
	vect_t n;
	bn_rand_sph_sample(p1, center, radius);
	bn_rand_sph_sample(p2, center, radius);
	VSUB2(n, p2, p1);
	VUNITIZE(n);
	rays[i*6+0] = p1[X];
	rays[i*6+1] = p1[Y];
	rays[i*6+2] = p1[Z];
	rays[i*6+3] = n[X];
	rays[i*6+4] = n[Y];
	rays[i*6+5] = n[Z];
    }
}

void
analyze_prand_pnt_worker(int cpu, void *ptr)
{
    struct application ap;
    struct rt_gen_worker_vars *state = &(((struct rt_gen_worker_vars *)ptr)[cpu]);
    size_t i;

    RT_APPLICATION_INIT(&ap);
    ap.a_rt_i = state->rtip;
    ap.a_hit = state->fhit;
    ap.a_miss = state->fmiss;
    ap.a_overlap = state->foverlap;
    ap.a_onehit = 0;
    ap.a_logoverlap = rt_silent_logoverlap;
    ap.a_resource = state->resp;
    ap.a_uptr = (void *)state;

    for (i = 0; i < state->rays_cnt; i++) {
	VSET(ap.a_ray.r_pt, state->rays[6*i+0], state->rays[6*i+1], state->rays[6*i+2]);
	VSET(ap.a_ray.r_dir, state->rays[6*i+3], state->rays[6*i+4], state->rays[6*i+5]);
	rt_shootray(&ap);
    }
}


int main(int argc, char **argv) {

    /* every application needs one of these */
    struct application	ap;
    static struct rt_i *rtip;	/* rt_dirbuild returns this */
    char idbuf[2048] = {0};	/* First ID record info */

    int status = 0;
    struct bu_vls buf = BU_VLS_INIT_ZERO;
    //struct shot sh;

    bu_setprogname(argv[0]);
    progname = argv[0];

    if (argc < 3) {
	usage("insufficient args\n");
    }

    /*
     *  Load database.
     *  rt_dirbuild() returns an "instance" pointer which describes
     *  the database to be ray traced.  It also gives you back the
     *  title string in the header (ID) record.
     */
    if ( (rtip=rt_dirbuild(argv[1], idbuf, sizeof(idbuf))) == RTI_NULL ) {
	bu_exit(2, "rtexample: rt_dirbuild failure\n");
    }

    /* initialize the application structure to all zeros */
    RT_APPLICATION_INIT(&ap);

    ap.a_rt_i = rtip;	/* your application uses this instance */

    /* Walk trees.
     * Here you identify any object trees in the database that you
     * want included in the ray trace.
     */
    while (argc > 2) {
	if ( rt_gettree(rtip, argv[2]) < 0 )
	    fprintf(stderr, "rt_gettree(%s) FAILED\n", argv[0]);
	argc--;
	argv++;
    }
  
    /* now looking at obj to points*/

    int pntcnt = 0;
    size_t i;
    int ret, j;
    int do_grid = 1;
    fastf_t oldtime, currtime;
    int ind = 0;
    int count = 0;
    double avgt = 0.0;
    size_t ncpus = bu_avail_cpus();
    struct rt_gen_worker_vars *state = (struct rt_gen_worker_vars *)bu_calloc(ncpus+1, sizeof(struct rt_gen_worker_vars ), "state");
    struct bu_ptbl **grid_pnts = NULL;
    struct bu_ptbl **rand_pnts = NULL;
    struct bu_ptbl **sobol_pnts = NULL;
    struct resource *resp = (struct resource *)bu_calloc(ncpus+1, sizeof(struct resource), "resources");
    int pntcnt_grid = 0;
    int pntcnt_rand = 0;
    int pntcnt_sobol = 0;

    oldtime = bu_gettime();

    for (i = 0; i < ncpus+1; i++) {
	/* standard */
	state[i].rtip = rtip;
	state[i].fhit = hit;
	state[i].fmiss = miss;
	state[i].foverlap = op_overlap;
	state[i].resp = &resp[i];
	state[i].ind_src = &ind;
	rt_init_resource(state[i].resp, (int)i, rtip);
    }

    while (argc > 2)  {
    if (rt_gettree(rtip, argv[2]) < 0)
        bu_log("Loading the geometry for [%s] FAILED\n", argv[2]);
    argc--;
    argv++;
    }

    rt_prep_parallel(rtip, (int)ncpus);

    currtime = bu_gettime();

    /* stop at the first point of intersection or shoot all the way
     * through (defaults to 0 to shoot all the way through).
     */
    ap.a_onehit = 0;

    /* This is what callback to perform on a hit. */
    ap.a_hit = hit;

    /* This is what callback to perform on a miss. */
    ap.a_miss = miss;

    fastf_t *rays;
	grid_pnts = (struct bu_ptbl **)bu_calloc(ncpus+1, sizeof(struct bu_ptbl *), "local state");
	for (i = 0; i < ncpus+1; i++) {
	    /* per-cpu hit point storage */
	    BU_GET(grid_pnts[i], struct bu_ptbl);
	    bu_ptbl_init(grid_pnts[i], 64, "first and last hit points");
	    state[i].ptr = (void *)grid_pnts[i];
	}

    /* there's a path to draw */
    struct bn_tol btol = BN_TOL_INIT_TOL;
    point_t rpp_min, rpp_max;
    btol.dist = DIST_PNT_PNT(rpp_max, rpp_min) * 0.01;

    count = analyze_get_bbox_rays(&rays, rtip->mdl_min, rtip->mdl_max, &btol);

	for (i = 0; i < ncpus+1; i++) {
	    state[i].step = (int)(count/ncpus * 0.1);
	    state[i].rays_cnt = count;
	    state[i].rays = rays;
	}

    oldtime = bu_gettime();
	bu_parallel(analyze_gen_worker, ncpus, (void *)state);
	currtime = bu_gettime();
	for (i = 0; i < ncpus+1; i++) {
	    state[i].rays = NULL;
	}

    int max_pnts = 1000;
    int max_time = 0;

    //size_t mrc = ((max_pnts * 10) > 2000000 || !max_pnts) ? 2000000 : max_pnts * 10;
    size_t mrc = 1000;
    size_t ccnt = (ncpus >= LONG_MAX-1) ? ncpus : ncpus+1;
    size_t craynum = mrc/ccnt;
	fastf_t mt = (fastf_t)INT_MAX;

    point_t center;

    VADD2SCALE(center, rtip->mdl_max, rtip->mdl_min, 0.5);

    // Random
    fastf_t delta = 0;
    size_t raycnt = 0;
    int pc = 0;
    rand_pnts = (struct bu_ptbl **)bu_calloc(ncpus+1, sizeof(struct bu_ptbl *), "local state");

    for (i = 0; i < ncpus+1; i++) {
        /* per-cpu hit point storage */
        BU_GET(rand_pnts[i], struct bu_ptbl);
        bu_ptbl_init(rand_pnts[i], 64, "first and last hit points");
        state[i].ptr = (void *)rand_pnts[i];
        if (!state[i].rays) {
            state[i].rays = (fastf_t *)bu_calloc(craynum * 6 + 1, sizeof(fastf_t), "rays");
            state[i].rays_cnt = craynum;
        }
    }

    oldtime = bu_gettime();
    while (delta < mt && raycnt < mrc && (!max_pnts || pc < max_pnts)) {
        for (i = 0; i < ncpus+1; i++) {
            get_random_rays(state[i].rays, craynum, center, rtip->rti_radius);
        }
        bu_parallel(analyze_prand_pnt_worker, ncpus, (void *)state);
        raycnt += craynum * (ncpus+1);
        pc = 0;
        for (i = 0; i < ncpus+1; i++) {
            pc += (int)BU_PTBL_LEN(rand_pnts[i]);
        }
        if (max_pnts && (pc >= max_pnts)) break;
        delta = (bu_gettime() - oldtime)/1e6;
    }

}
